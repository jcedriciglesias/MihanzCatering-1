@extends('layouts.app')

@section('content')
<link rel="stylesheet" href="{{ asset('css/menu.css') }}">

<h1 class="display-1 text-center">{{ $categoryName }}</h1>
<div class="menu-selection">
    <ul>
        @foreach($menus as $menu)
        <li data-bs-toggle="modal" data-bs-target="#menuModal{{ $menu->id }}">
            <h2 class="display-6">{{ $menu->name }}</h2>
            <img src="{{ asset('images/menu/' . $menu->menus_image) }}" alt="" class="img-thumbnail">
        </li>

        <!-- Modal -->
        <div class="modal fade" id="menuModal{{ $menu->id }}" tabindex="-1" aria-labelledby="menuModalLabel{{ $menu->id }}" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="menuModalLabel{{ $menu->id }}">{{ $menu->name }}</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <img src="{{  asset('images/menu/' . $menu->menus_image) }}" alt="" class="img-thumbnail">
                        <div class="info">
                            <h1 class="display-4 text-center">{{ $menu->name }}</h1>
                            <p class="text-center fw-bolder">
                                Price: ${{ $menu->price }}
                            </p>
                            <p class="text-center">
                                {{ $menu->description }}
                            </p>
                        </div>
                    </div>
                    <div class="modal-footer">
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </ul>
</div>
@endsection
