@extends('layouts.app')

@section('content')
    <link rel="stylesheet" href="{{ asset('css/themes.css') }}">

    <div id="carouselExampleDark" class="carousel carousel-dark slide" data-ride="carousel">
        <div class="carousel-indicators">
            @foreach ($themesItems as $key => $themesItem)
                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="{{ $key }}" class="{{ $key === 0 ? 'active' : '' }}" aria-current="{{ $key === 0 ? 'true' : 'false' }}" aria-label="Slide {{ $key + 1 }}"></button>
            @endforeach
        </div>

        <div class="carousel-inner">
            @foreach ($themesItems as $key => $themesItem)
                <div class="carousel-item {{ $key === 0 ? 'active' : '' }}" data-bs-interval="10000">
                    <img src="{{ $themesItem->theme_image }}" class="d-block w-100" alt="...">

                    <div class="carousel-caption d-none d-md-block">
                        <h5>{{ $themesItem->theme_name }}</h5>
                    </div>
                </div>
            @endforeach
        </div>

        <a class="carousel-control-prev" href="#carouselExampleDark" role="button" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </a>

        <a class="carousel-control-next" href="#carouselExampleDark" role="button" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </a>
    </div>
@endsection
