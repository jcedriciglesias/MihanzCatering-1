

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/services.css')); ?>">

    <div class="Services-Container ">
        <h1 class="display-1 ">Services</h1>
<hr>
        <ul >
        <?php $__currentLoopData = $servicesItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $servicesItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="birthday" style="background-image: linear-gradient(rgba(0,0,0,50%),rgba(0,0,0,50%)), url(<?php echo e($servicesItem->services_image); ?>);">
                <a href="<?php echo e(route('user.servicePackages', ['serviceCategory' => $servicesItem->services_category])); ?>" class="display-2"><?php echo e($servicesItem->services_category); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Capstone\Rushers\mihanz-catering-final\mihanz-catering\resources\views/user/services.blade.php ENDPATH**/ ?>