

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/services.css')); ?>">

    <div class="pre-made">
        <h1 class="display-1 text-center title "><?php echo e($categoryName); ?> Promos</h1>
        <p>Choose a package that you desire</p>
        <ul>
        <?php $__currentLoopData = $promos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="../form/Premade.html">
            <li >
              <h1 class="display-4 text-center"><?php echo e($promo->name); ?> </h1>
              <img src="<?php echo e(asset('images/services/packages/' . $promo->service_pckg_image)); ?>" class="img-fluid" alt="Package 1">
            </li>
          </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <a href="../customize/custom-package.html">
            <li >
              <h1 class="display-4 text-center">Customize base on your budget </h1>
            </li>
          </a>
          <a href="../MostOrderedMenu.html">
            <li >
              <h1 class="display-4 text-center">Most Ordered Menu</h1>
              
            </li>
          </a>
        </ul>
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Capstone\Rushers\mihanz-catering-final\mihanz-catering\resources\views/user/servicePackages.blade.php ENDPATH**/ ?>