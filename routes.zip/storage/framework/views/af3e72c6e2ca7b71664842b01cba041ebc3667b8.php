

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/menu.css')); ?>">

    <div class="menu ">
          <h1 class="display-1 text-center">Menu</h1>
          <ul>
          <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li style="background-image: linear-gradient(rgba(0,0,0,50%),rgba(0,0,0,50%)), url(<?php echo e($menuItem->menu_image); ?>);"><a href="/menus/<?php echo e($menuItem->menu_category); ?>" class="display-4 text-center target"><?php echo e($menuItem->menu_category); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Capstone\Rushers\mihanz-catering-final\mihanz-catering\resources\views/user/menus.blade.php ENDPATH**/ ?>