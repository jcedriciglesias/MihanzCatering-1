

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/menu.css')); ?>">

<h1 class="display-1 text-center"><?php echo e($categoryName); ?></h1>
<div class="menu-selection">
    <ul>
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li data-bs-toggle="modal" data-bs-target="#menuModal<?php echo e($menu->id); ?>">
            <h2 class="display-6"><?php echo e($menu->name); ?></h2>
            <img src="<?php echo e(asset('images/menu/' . $menu->menus_image)); ?>" alt="" class="img-thumbnail">
        </li>

        <!-- Modal -->
        <div class="modal fade" id="menuModal<?php echo e($menu->id); ?>" tabindex="-1" aria-labelledby="menuModalLabel<?php echo e($menu->id); ?>" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="menuModalLabel<?php echo e($menu->id); ?>"><?php echo e($menu->name); ?></h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <img src="<?php echo e(asset('images/menu/' . $menu->menus_image)); ?>" alt="" class="img-thumbnail">
                        <div class="info">
                            <h1 class="display-4 text-center"><?php echo e($menu->name); ?></h1>
                            <p class="text-center fw-bolder">
                                Price: $<?php echo e($menu->price); ?>

                            </p>
                            <p class="text-center">
                                <?php echo e($menu->description); ?>

                            </p>
                        </div>
                    </div>
                    <div class="modal-footer">
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Capstone\Rushers\mihanz-catering-final\mihanz-catering\resources\views/user/menuContainer.blade.php ENDPATH**/ ?>