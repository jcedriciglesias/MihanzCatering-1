

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/themes.css')); ?>">

    <div id="carouselExampleDark" class="carousel carousel-dark slide" data-ride="carousel">
        <div class="carousel-indicators">
            <?php $__currentLoopData = $themesItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $themesItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="<?php echo e($key); ?>" class="<?php echo e($key === 0 ? 'active' : ''); ?>" aria-current="<?php echo e($key === 0 ? 'true' : 'false'); ?>" aria-label="Slide <?php echo e($key + 1); ?>"></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="carousel-inner">
            <?php $__currentLoopData = $themesItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $themesItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php echo e($key === 0 ? 'active' : ''); ?>" data-bs-interval="10000">
                    <img src="<?php echo e($themesItem->theme_image); ?>" class="d-block w-100" alt="...">

                    <div class="carousel-caption d-none d-md-block">
                        <h5><?php echo e($themesItem->theme_name); ?></h5>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <a class="carousel-control-prev" href="#carouselExampleDark" role="button" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </a>

        <a class="carousel-control-next" href="#carouselExampleDark" role="button" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Capstone\Rushers\mihanz-catering-final\mihanz-catering\resources\views/user/themes.blade.php ENDPATH**/ ?>