<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

  <title>Mihan'z Catering</title>
</head>

<body>

  <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Mihanz Catering</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="nav nav-tabs ">
          <?php if(auth()->guard()->guest()): ?>
          <li class="nav-item">
                            <a class="nav-link <?php echo e(Request::is('/') ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>"><?php echo e(__('Home')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Request::is('menus') ? 'active' : ''); ?>" href="<?php echo e(url('/menus')); ?>"><?php echo e(__('Menu')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Request::is('services') ? 'active' : ''); ?>" href="<?php echo e(url('/services')); ?>"><?php echo e(__('Services')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(Request::is('themes') ? 'active' : ''); ?>" href="<?php echo e(url('/themes')); ?>"><?php echo e(__('Theme')); ?></a>
                        </li>
          <?php if(Route::has('login')): ?>
          <li class="nav-item">
                                <a class="nav-link <?php echo e(Request::is('login') ? 'active' : ''); ?>" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
          <?php endif; ?>

          <?php if(Route::has('register')): ?>
          <li class="nav-item">
                                <a class="nav-link <?php echo e(Request::is('register') ? 'active' : ''); ?>" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                            </li>
          <?php endif; ?>
          
          <?php else: ?>
          <li class="nav-item">
            <?php if(auth()->check()): ?>
            <?php if(auth()->user()->hasRole('admin')): ?>
            <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
            <?php else: ?>
            <a class="nav-link" href="<?php echo e(route('user.dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
            <?php endif; ?>
          </li>
          <?php endif; ?>
          <li class="nav-item">
                                <a class="nav-link <?php echo e(Request::is('menus') ? 'active' : ''); ?>" href="<?php echo e(url('/menus')); ?>"><?php echo e(__('Menu')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(Request::is('services') ? 'active' : ''); ?>" href="<?php echo e(url('/services')); ?>"><?php echo e(__('Services')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(Request::is('themes') ? 'active' : ''); ?>" href="<?php echo e(url('/themes')); ?>"><?php echo e(__('Theme')); ?></a>
                            </li>
          <li class="nav-item dropdown">
            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
              <?php echo e(Auth::user()->name); ?>

            </a>

            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="">
                <?php echo e(__('User Profile')); ?>

              </a>
              <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                             document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

              </a>

              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
              </form>
            </div>
          </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav>
  <main>

    <?php echo $__env->yieldContent('content'); ?>

  </main>






  <!-- footer -->

  <footer>
    <h1 class="display-1 ">
      Mihanz Catering
    </h1>

    <ul>
      <li>
        <label for="getInTouch" class="h3">Get in touch</label>
        <br /><a href="https://www.facebook.com/profile.php?id=100066545202436" target="_blank" rel="noreferrer">
          <FaFacebook />Facebook
        </a>
      </li>
      <li>
        <label for="Contact" class="h3">Contact</label><br />
        <a href="#">
          <FaMobileScreen />0926-563-1143 <br />
          <FaMobileScreen /> 0916-412-2250
        </a>
      </li>
      <li>
        <label for="Location" class="h3">Location</label> <br />
        <a href="https://goo.gl/maps/eYMwkLUwLh3tVrsLA" target="_blank" rel="noreferrer">
          <FaMapLocationDot /> Calderon St. Subic
          Baliwag, Bulacan
        </a>

      </li>
      <a href="/ADMIN/Index.html"> Admin</a>
    </ul>

  </footer>
</body>

</html><?php /**PATH D:\xampp\htdocs\Capstone\Rushers\mihanz-catering-final\mihanz-catering\resources\views/layouts/app.blade.php ENDPATH**/ ?>