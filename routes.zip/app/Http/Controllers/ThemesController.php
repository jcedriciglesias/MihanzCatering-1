<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ThemeSelection;


class ThemesController extends Controller
{
    public function index()
    {
        $themesItems = ThemeSelection::all();
        foreach ($themesItems as $themesItem) {
            $themesItem->theme_image = asset("images/themes/".rawurlencode($themesItem->theme_image));
        }
        return view('user.themes', ['themesItems' => $themesItems]);
    }
}
